Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_sockets_option("TLS_SNI", "0");

	web_set_user("demouser2", 
		lr_unmask("6596dab601f0677554f07deaf9642b"), 
		"advantageonlineshopping.com:443");

	web_add_cookie("userCart=%7B%22userId%22%3A-1%2C%22productsInCart%22%3A%5B%5D%7D; DOMAIN=advantageonlineshopping.com");

	web_url("advantageonlineshopping.com", 
		"URL=https://advantageonlineshopping.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/main.min.js", ENDITEM, 
		"Url=/services.properties", ENDITEM, 
		"Url=/css/images/logo.png", ENDITEM, 
		"Url=/css/images/closeDark.png", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=laptops", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=tablets", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=speakers", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=mice", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=headphones", ENDITEM, 
		"Url=/css/images/Special-offer.jpg", ENDITEM, 
		"Url=/css/images/facebook.png", ENDITEM, 
		"Url=/css/images/GoUp.png", ENDITEM, 
		"Url=/css/images/twitter.png", ENDITEM, 
		"Url=/css/images/linkedin.png", ENDITEM, 
		"Url=/css/images/Banner1.jpg", ENDITEM, 
		"Url=/css/images/Popular-item3.jpg", ENDITEM, 
		"Url=/css/images/Popular-item2.jpg", ENDITEM, 
		"Url=/css/images/Banner2.jpg", ENDITEM, 
		"Url=/css/images/Banner3.jpg", ENDITEM, 
		"Url=/css/images/Popular-item1.jpg", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5400", ENDITEM, 
		"Url=/css/images/category_banner_5.png", ENDITEM, 
		"Url=/css/images/Filter.png", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5505", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5800", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5300", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5200", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5700", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5100", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5600", ENDITEM, 
		"Url=/catalog/fetchImage?image_id=5900", ENDITEM, 
		"Url=/css/images/User.jpg", ENDITEM, 
		"Url=/css/images/Shipex.png", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=120", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("ALL", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/DemoAppConfig/parameters/by_tool/ALL", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/roboto_regular_macroman/Roboto-Regular-webfont.woff", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_light_macroman/Roboto-Light-webfont.woff", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_medium_macroman/Roboto-Medium-webfont.woff", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	web_custom_request("GetAccountConfigurationRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/GetAccountConfigurationRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetAccountConfigurationRequest xmlns=\"com.advantage.online.store.accountservice\"></GetAccountConfigurationRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_url("categories", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/categories", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_url("search", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/deals/search?dealOfTheDay=true", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_url("popularProducts.json", 
		"URL=https://advantageonlineshopping.com/app/tempFiles/popularProducts.json", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_url("home-page.html", 
		"URL=https://advantageonlineshopping.com/app/views/home-page.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/images/arrow_right.png", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_thin_macroman/Roboto-Thin-webfont.woff", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/fonts/roboto_bold_macroman/Roboto-Bold-webfont.woff", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		"Url=/css/images/FacebookLogo.png", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	lr_think_time(9);

	lr_start_transaction("user_transaction");

	lr_end_transaction("user_transaction",LR_AUTO);

	web_custom_request("v2", 
		"URL=https://clientservices.googleapis.com/uma/v2", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/vnd.chrome.uma", 
		"BodyBinary=\t\\xFDt\r@Z\\xA8\\xC1\\x17\\x10\\xA1\n\\x1A\\xB3\n\\x08\\xDC\\xC4\\x87\\xAC\\x06\\x12\\x11120.0.6099.130-64\\x18\\xA0\\xD7\\xFC\\x8F\\x06\"\\x05en-US*\\x18\n\nWindows NT\\x12\n10.0.190452p\n\\x06x86_64\\x10\\x8A7\\x18\\x80\\x80\\x8C\\xE6\\xCF\\xFF\\x1F\"\\x0EVostro 15-3568(\\x010\\xD6\n8\\x80\\x06B\n\\x08\\x00\\x10\\x00\\x1A\\x002\\x00:\\x00M'\\xB9\\xC9BU\\xAC%\\xCABe\\x00\\x00\\x80?j\\x16\n\\x0CGenuineIntel\\x10\\xE3\\x8D\\x10\\x18\\x04 "
		"\\x00\\x82\\x01\\x00\\x8A\\x01\\x00\\xAA\\x01\\x06x86_64\\xB0\\x01\\x01J\n\r\\xF4\\x1E\\xE6\\x0E\\x15\\x80\\x8D}\\xCAJ\n\r\\x82\r\\xDD\\xED\\x15\\xE9\\xED#wJ\n\r\\xA3\\xD2\\x95\\xD3\\x15\\x80\\x8D}\\xCAJ\n\r\\x95\\xAA\\x950\\x15\\xDF\\x17J?J\n\r\\xBE\\xEB\\x8Fr\\x15\\x06\\xC6\\xAC\\x94J\n\rR_`\\x98\\x15\\x80\\x8D}\\xCAJ\n\r4W\\x15\\xDA\\x15Z\\xE5{7J\n\r\\x9A\\xBEY\\xCD\\x15\\x80\\x8D}\\xCAJ\n\r\\x99mfD\\x15\\x80\\x8D}\\xCAJ\n\rB\\xC5\\xF5\\xF6\\x15\\xA2\\xE6\\xED\\x12J\n\r"
		"\\xDC\\xC6\\xC2\\x7F\\x15\\x92\\xFB\\x95\\xBFJ\n\rY\\xF7\\xCF\\xB2\\x15Y\\xF7\\xCF\\xB2J\n\r\\xB8\\xA1\\x82\\xA5\\x15=\\xF4\\xD3ZJ\n\r2\\x8A\\x9B\\xCE\\x15\\x87\\xAC/MJ\n\r\\xB4\\x97-\\xD9\\x15\\x80\\x8D}\\xCAJ\n\r\\xB1$\\x19\\xAE\\x15\\xAF\\xB4@(J\n\rSYf&\\x15\\x80\\x8D}\\xCAJ\n\r\\x16?\\xD3?\\x15\\x80\\x8D}\\xCAJ\n\r\\x98\\x88M\\x19\\x15Z\\xE5{7J\n\r\\x07\\xFEO:\\x15\\x917\\xE3\\xBAJ\n\r\\x03\\xF2r\\xC2\\x15\\xA2\\xE6\\xED\\x12J\n\r\\x8D\\xF1j&\\x15\\xED\\xC8]\\xABJ\n\r\\xB3f\\xEAo\\x15Z\\xE5"
		"{7J\n\r\\xCA\\x93\\x15\\xE4\\x15\\x80\\x8D}\\xCAJ\n\r\\x9A!\\xCF\\xBA\\x15\\x80\\x8D}\\xCAJ\n\rm#:^\\x15d\\xC4;`J\n\r\\x92~Jx\\x15\\x80\\x8D}\\xCAJ\n\r\\xA3%\\xE9\\xCB\\x15\\x80\\x8D}\\xCAJ\n\r\\xDA\\x7FN+\\x15\\xFD\\xD6@\\xAFJ\n\r\\xDF\\xE0\\x90\\xEA\\x153\\xD7\\xF7NJ\n\r\\x85|\\xF19\\x15\\xF7\\xC9\\x1F\\xEFJ\n\re\\xBB\\xF2\\x84\\x15U@N\rJ\n\r\\xD0o\\xC4\\x16\\x15\\x80\\x8D}\\xCAJ\n\r\\xD9\\x1E\\xB7\\xB8\\x15\\x80\\x8D}\\xCAJ\n\r\\xE7\\xED\\xCE\\xDC\\x15)\\x0FF\\x05J\n\r"
		"\\x81\\xC1\\x89.\\x15sY\\x8C\\x1FJ\n\r\\xB5\\xCE3\\xFA\\x15\\x12\\xA6O'J\n\rR\\xF6\\x87\\xCB\\x15\\xA5\\xEB\\xC33J\n\r<=I\\xDA\\x15\\x80\\x8D}\\xCAJ\n\r\\xC4\\xDF\\xD7>\\x15\\x80\\x8D}\\xCAJ\n\r\\xCB1of\\x15Z\\xE5{7J\n\r\\xBE/\\xA1Y\\x156\\xC3~\\xC0J\n\r\\x8EtN\\\\\\x15\\x14\\xA5\\xBB\\x02J\n\r\\x88\\xA0#\\xEA\\x15Z\\xE5{7J\n\r\\xF0KX\\x8C\\x15\\x80\\x8D}\\xCAJ\n\r//Z\\x04\\x156\\xCAu\\\\J\n\ri@Q\\x83\\x15\\x80\\x8D}\\xCAJ\n\r\\xFE\\xF67\\x01\\x15\\x87\\xAC/MJ\n\r"
		"\\xA6\\x03\\xA3N\\x15\\x0E%\\xBB\\xECJ\n\r\\xB9\\xC5\\xED\\x94\\x15Z\\xE5{7J\n\r\\x11\\xB3\\xEF\\xF1\\x15\\x80\\x8D}\\xCAJ\n\r0\\xA7\\xCA\\xA6\\x15\\x80\\x8D}\\xCAJ\n\r\\xF4\\xDD\\xDC\\x1E\\x15\\xD5\\x13\\x9DeJ\n\rRS\\xA6\\xD5\\x15sY\\x8C\\x1FJ\n\r<1K\\xFD\\x15\\x9E\\x9EjfJ\n\r\\xD1#(?\\x15\\xEA\\x1D=\\xF2J\n\r\r\\x00\\x18\\x19\\x15\\x80\\x8D}\\xCAJ\n\r\\x13a\\x1A\\xCD\\x15\\x80\\x8D}\\xCAJ\n\rG3\\x08\\xD0\\x15\\x80\\x8D}\\xCAJ\n\r\\x10\\x92>\\xF4\\x15\\x80\\x8D}\\xCAJ\n\r`\\x87MI\\x15C]2RJ\n\r"
		"\\x99 \\x1A\\xE7\\x15\\x0B$\\x8F\\xF0J\n\r\\xC2s({\\x15 iO\\xB1J\n\rU\\x08\\xC6:\\x15\\x9C*nHJ\n\r\\xA3\\xB6\\xDCc\\x15\\x923.\\xB5J\n\rF\\xE7\\x06\\xE7\\x15W\\xBB\\xC2OJ\n\r\\x0C\\x19\\x96\\xF2\\x15Q\\xB9!\\x95J\n\r\\xE2\\xAABD\\x15v\\x19;nJ\n\rd\\xCF\\x90\\xF6\\x15v\\x19;nJ\n\rw\\xD3\\xD1\\x0E\\x15\\x14\\x0F\\xCC\\xE1J\n\r\\xA0\\xF0\\xF0u\\x15<\\xB1\\xF6\\xD7J\n\r\\x90?\\x0Cq\\x15<\\xB1\\xF6\\xD7J\n\r\\x81\\x84\\xB1\\xE2\\x15\\xDE~YnJ\n\r\\x89\\x18\\xE7\\xE7\\x15u\\x05\\xD6JJ\n\r"
		"\\x9B\\xA2\\x8A\\x85\\x15Z\\xE5{7J\n\r\\xFD\\xDA\\x10\\x05\\x15\\x80\\x8D}\\xCAJ\n\rQ\\xE4U|\\x15X\\xBE\\xD9\\x00J\n\r\\x81\\xF0\\x8E\\xF3\\x15\\xA2\\xE6\\xED\\x12J\n\r_\\x90\\x08\\xDD\\x15\\xE7\\xB77\\xF6J\n\ra\\xFA\nE\\x15\\x83\\xB7\\xC1\\x0EJ\n\r\\x01\\x96\\xCFm\\x15\\x80\\x8D}\\xCAJ\n\r\\xEA\\x91T\\xC5\\x15lc\\x0BKJ\n\r\\xB3i\\x8F\\xA3\\x15cv\\x9F\\xB5J\n\r\\xBAm\\xD2;\\x15\\xFC\\x1D\\x07\\xADJ\n\r<\\xDB\\x07S\\x15\\xF4\\xF4G=P\\x04Z\\x02\\x08\\x00b\\x04GGLSj\\x0C\\x08\\x00\\x10\\x00\\x18\\x00"
		" \\x068\\x00@\\x00\\x80\\x01\\xA0\\xD7\\xFC\\x8F\\x06\\x98\\x01\\x00\\xB0\\x01\\x01\\xE2\\x01\\x1620240103-180820.993000\\xF8\\x01\\xF2\\x16\\x80\\x02\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\xFF\\x01\\x88\\x02\\x01\\x92\\x02$4032c3c9-43ff-48b3-8c4b-8f6ca21d497c\\xA8\\x02\\x8A6\\xB2\\x02\\x04\\x04%\\x80\\xFB2\r\tVM\\xC4\\xD3\\xE0\\x1D],\\x1A\\x02\\x10\\x012\\x0F\t_\\xFC\\xBB9\\xAF\\x97\\xD3\\x9A\\x10\\x01\\x1A\\x02\\x10\\x022\\x11\t"
		"\\x17\\xF9\\xCB\\xEA\\x16s\\xCD\\x8C\\x10\\xFA\\x06\\x1A\\x03\\x10\\xFB\\x06\\xE0\\x01\\xD3\\x13", 
		LAST);

	web_custom_request("json", 
		"URL=http://update.googleapis.com/service/update2/json?cup2key=13:z1u908xzvbskv3c31x2tU97YvsgeF8yOXlImXF6TpzE&cup2hreq=bd4888dac96e88095a33af4b100df47e825c8f0f5aaf5a97ed5a12f6e89731b3", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"cohorthint\":\"Win (Including up-to-date)\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.30f5f886b824ca1efde5174370fc03cab3c02e9c309bc381857430f5843a510b\"}]},\"ping\":{\"ping_freshness\":\"{662a6ada-537d-4656-af42-5dddbbc6f8d3}\",\"rd\":6212},\"updatecheck\":{},\"version\":\""
		"1.3.36.311\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"GGLS\",\"cohort\":\"1:1299:\",\"cohorthint\":\"Windows (102+, canary/dev/beta/stable)\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":5818,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{d3717ceb-6fb4-413b-9643-f1b6432a41a9}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"accept_locale\""
		":\"ENUS500000\",\"appid\":\"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"GGLS\",\"cohort\":\"1:s6f:20ol@0.5\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.50a410468d64fd55a0fc41dd22d574883f13386eb147b0b5b96ee66c118d4d6e\"}]},\"ping\":{\"ping_freshness\":\"{fa6d79bd-82f3-41cf-b6f0-02513e0358bf}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"20230916.567854667.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\""
		"brand\":\"GGLS\",\"cohort\":\"1:lwl:25i9@0.5\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.23d23205a85fd30aa8d58030843cbf59c8700f1b60aaf1c5e058e574b3876c7d\"}]},\"ping\":{\"ping_freshness\":\"{01f09293-0c87-482f-9664-2c721a82a220}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"427\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"GGLS\",\"cohort\":\"1:v3l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\","
		"\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.4a6508925b2ffec931c1e3931ddeb15ca41d820a8264cd5a962b526e9932bcdf\"}]},\"ping\":{\"ping_freshness\":\"{71748586-2cc0-4cbc-8c70-a49f75db1db2}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"2024.1.2.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.fd515ec0dc30d25a09641b8b83729234bc50f4511e35ce17d24fd996252eaace\"}]},\"ping\":{\"ping_freshness\":\"{300f71ef-8445-4f63-a236-abcbd646c084}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.f4f1eb04881095d1cc8f2e1799a8144c10476dc1088a03ecdb4418644040a554\"}]},\"ping\":{\""
		"ping_freshness\":\"{c4b473ee-891a-4577-a433-77834c0a05ba}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"63\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"cohort\":\"1:1zdx:\",\"cohorthint\":\"4.10.2557.0 for Chrome 95+\",\"cohortname\":\"Chrome 106+\",\"enabled\":true,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{754413c5-e193-438a-949c-46e28ed1afd8}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\""
		"brand\":\"GGLS\",\"cohort\":\"1:bm1:\",\"cohorthint\":\"M54AndUp\",\"cohortname\":\"Stable\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{156265e5-e148-428a-a93d-c014813c5a47}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"cohort\":\"1::\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":"
		"{\"package\":[{\"fp\":\"1.3e4f959036fef1cae2b1f426864a23f11caae1c96a2816523f2daf4213c3cc73\"}]},\"ping\":{\"ping_freshness\":\"{d3c15c9d-7005-4a13-b970-1f517fc8807f}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"1.0.0.14\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"GGLS\",\"cohort\":\"1:10zr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{d82a3306-c28a-45cb-b40a-1126bb161860}\",\"rd\":6212},\"updatecheck\":{"
		"},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\"cohort\":\"1:ofl:\",\"cohorthint\":\"stable32\",\"cohortname\":\"stable64\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{8da00639-5183-4590-8f67-97d76d2ff0ea}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\""
		"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"GGLS\",\"cohort\":\"1:18ql:\",\"cohorthint\":\"Auto Stage3\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.9638eb258b056dff2129ae34b37d2a107e600cafb66e430f501b163e421ac1aa\"}]},\"ping\":{\"ping_freshness\":\"{eb6c11db-afd4-4ad1-ad78-8797c7aaa6b6}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"817\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\""
		"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7725493ed68e793a0033e02d76eb3d72a848b9a519394d0865088d34555b6a26\"}]},\"ping\":{\"ping_freshness\":\"{aa40af6e-0132-4bd3-8bf7-b5cab86fc6b4}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"3012\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\":\"GGLS\",\"cohort\":\"1:wvr:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\""
		":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{7c8d7eca-504a-4794-a79c-d894a5276a39}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"GGLS\",\"cohort\":\"1:ut9/1a0f/23ml/23mr:\",\"cohorthint\":\"108-and-above-all-users\",\"cohortname\":\"Control\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.c45cd56a0a8da0883c8f9757b31891d6c628f38cb80724015ffdf33b419a73f3\"}]},\"ping\":{\"ping_freshness\":\"{a7ddc09a-a177-43ab-9eaf-a224a8390b36}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"2023.11.27.1202\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"GGLS\",\"cohort\":\"1:w0x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"All users\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\""
		"ping\":{\"ping_freshness\":\"{5864eecf-8c5a-453a-a48e-64025068908a}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"GGLS\",\"cohort\":\"1:24vr:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6154,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.27eea7f9103464afe70f767435f76ba57ec36b60f896fcedf160aaac2a2e4b3e\"}]},\"ping\":{\"ping_freshness\":\"{b18daa9e-437b-4601-978f-7f4569030ef2}\",\"rd\":6212},\"updatecheck"
		"\":{},\"version\":\"2024.1.3.1\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.aff3d2026b3b503562a64dc979205b4602dd313e30c4528c59e3dce9e4e8b50e\"}]},\"ping\":{\"ping_freshness\":\"{34468f61-5193-4c31-9671-b355e93b3620}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"8464\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\""
		"GGLS\",\"cohort\":\"1:w59:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c64c9c1008f3ba5f6e18b3ca524bc98dcd8acfae0a2720a8f1f3ef0f8d643d05\"}]},\"ping\":{\"ping_freshness\":\"{453d0acf-da8b-41ff-bd81-3a2726327b68}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"2020.11.2.164946\"},{\"appid\":\"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"GGLS\",\"cohort\":\"1:z1x:25p3@0.025\",\"cohorthint\":\"General release\",\""
		"cohortname\":\"Auto\",\"enabled\":true,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.ae46d431f381538b0fac6d9fc4ddd1c83253f4d720aff5bbb342cbd1da3c01a2\"}]},\"ping\":{\"ping_freshness\":\"{5254246a-da5a-45a1-bad6-760158d4def8}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"2023.12.20.0\"},{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"GGLS\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6133,\"lang\":\"en-US\",\"packages\":{\""
		"package\":[{\"fp\":\"1.b052dcc90b2eb5b223c5a6b63591cddb4c5e470ccdd968201e779dc2995c84eb\"}]},\"ping\":{\"ping_freshness\":\"{a088c7f9-4bda-43a6-a259-2556a062bc76}\",\"rd\":6212},\"updatecheck\":{},\"version\":\"2024.1.3.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":7,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\""
		"Windows\",\"version\":\"10.0.19045.3693\"},\"prodversion\":\"120.0.6099.130\",\"protocol\":\"3.1\",\"requestid\":\"{d5314a4d-dc72-4021-9d24-955f28f76070}\",\"sessionid\":\"{7c43f576-de0a-4a81-8324-8e88c182663d}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.36.352\"},\"updaterversion\":\"120.0.6099.130\"}}", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch4KDGdvb2dsZWNocm9tZRIOMTIwLjAuNjA5OS4xMzAaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARDMzBQaAhgGamXWySIEIAEgAigBGikIARABGhsKDQgBEAYYASIDMDAxMAEQ_9ANGgIYBmhfLsMiBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABELHIDRoCGAZYYgb_IgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARCNqwcaAhgGGGULKiIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQizcaAhgGReqx5SIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQ1JMCGgIYBmSi_wsiBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAcaAhgGJri8liIEIAEgAigBGicICRABGhkKDQgJEAYYASIDMDAxMAEQIxoCGAY7oyz2IgQgASACKAEaKAgIEA"
		"EaGgoNCAgQBhgBIgMwMDEwARCLFRoCGAbpYcRLIgQgASACKAEaKQgNEAEaGwoNCA0QBhgBIgMwMDEwARCZiAIaAhgGvSIpriIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQuZcOGgIYBv5GUEIiBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEJUgGgIYBiNY4mkiBCABIAIoASICCAM=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIwLjAuNjA5OS4xMzASUQkAV538LJqhZBIFDeeNQA4SBQ3OQUx6EgUNeG8SGRIFDQ8WvisSBQ2E5pjgEgUN9nKYWRIFDcd2OFASBQ1axjztEgUNcpdcLyG_nUdXxrOJoA==?alt=proto", "Referer=", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	lr_start_transaction("login_transaction");

	web_custom_request("AccountLoginRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/AccountLoginRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><AccountLoginRequest xmlns=\"com.advantage.online.store.accountservice\"><email></email><loginPassword>Demouser123</loginPassword><loginUser>demouser2</loginUser></AccountLoginRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_set_sockets_option("INITIAL_AUTH", "BASIC");

	web_url("655606527", 
		"URL=https://advantageonlineshopping.com/order/api/v1/carts/655606527", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("655606527_2", 
		"URL=https://advantageonlineshopping.com/order/api/v1/carts/655606527", 
		"Method=PUT", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"Body=[{\"hexColor\":\"414141\",\"productId\":29,\"quantity\":1}]", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_end_transaction("login_transaction",LR_AUTO);

	web_custom_request("upload", 
		"URL=https://beacons2.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_CERT_COMMON_NAME_INVALID\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":79725,\"request_elapsed_ms\":481,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"ssl.cert.name_invalid\",\"url\":\"https://www.google-analytics.com/analytics.js\",\"was_proxied\":false}],\"reporter\":\"chrome\"}", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_custom_request("upload_2", 
		"URL=https://beacons2.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_CERT_COMMON_NAME_INVALID\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":91662,\"request_elapsed_ms\":3481,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"ssl.cert.name_invalid\",\"url\":\"https://www.googletagmanager.com/\",\"was_proxied\":false}],\"reporter\":\"chrome\"}", 
		LAST);

	lr_think_time(5);

	lr_start_transaction("mice_transaction");

	web_url("products", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/categories/5/products", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_url("attributes", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/categories/attributes", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		LAST);

	web_url("category-page.html", 
		"URL=https://advantageonlineshopping.com/app/views/category-page.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIwLjAuNjA5OS4xMzASLgk0obaTTtv-JhIFDeeNQA4SBQ3OQUx6EgUNeG8SGRIFDQ8WvishPHbFEvZHhmI=?alt=proto", "Referer=", ENDITEM, 
		"Url=/css/images/Check.png", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	lr_end_transaction("mice_transaction",LR_AUTO);

	lr_think_time(91);

	lr_start_transaction("filtering_transaction");

	lr_end_transaction("filtering_transaction",LR_AUTO);

	lr_start_transaction("select_mouse_transaction");

	web_url("all_data", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/categories/all_data", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");

	web_url("29", 
		"URL=https://advantageonlineshopping.com/catalog/api/v1/products/29", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_url("product-page.html", 
		"URL=https://advantageonlineshopping.com/app/views/product-page.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("select_mouse_transaction",LR_AUTO);

	web_custom_request("upload_3", 
		"URL=https://beacons2.gvt2.com/domainreliability/upload", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/javascript", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"entries\":[{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":174188,\"request_elapsed_ms\":615,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/\",\"was_proxied\":false},{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":174185,\"request_elapsed_ms\":1615,\"sample_rate\":1.0,\"server_ip\":\"\",\""
		"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/\",\"was_proxied\":false},{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":95622,\"request_elapsed_ms\":263,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/\",\"was_proxied\":false},{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":95619,\""
		"request_elapsed_ms\":1292,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/\",\"was_proxied\":false},{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":3397,\"request_elapsed_ms\":235,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/\",\"was_proxied\":false},{\"failure_data\":{\"custom_error\":\"net::ERR_ABORTED\"},\""
		"network_changed\":false,\"protocol\":\"\",\"request_age_ms\":3395,\"request_elapsed_ms\":643,\"sample_rate\":1.0,\"server_ip\":\"\",\"status\":\"aborted\",\"url\":\"https://beacons.gcp.gvt2.com/\",\"was_proxied\":false}],\"reporter\":\"chrome\"}", 
		LAST);

	lr_think_time(44);

	lr_start_transaction("quantity_transaction");

	lr_end_transaction("quantity_transaction",LR_AUTO);

	lr_start_transaction("add_to_cart_transaction");

	web_submit_data("414141", 
		"Action=https://advantageonlineshopping.com/order/api/v1/carts/655606527/product/29/color/414141?quantity=1", 
		"Method=POST", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=sessionId", "Value=EC1DFE9DC3CD2D4AA1720D327E761ADC", ENDITEM, 
		LAST);

	lr_end_transaction("add_to_cart_transaction",LR_AUTO);

	lr_think_time(42);

	lr_start_transaction("click_on_cart_transaction");

	web_url("655606527_3", 
		"URL=https://advantageonlineshopping.com/order/api/v1/carts/655606527", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_url("shoppingCart.html", 
		"URL=https://advantageonlineshopping.com/app/views/shoppingCart.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("click_on_cart_transaction",LR_AUTO);

	lr_think_time(19);

	lr_start_transaction("checkout_transaction");

	web_custom_request("GetAccountByIdRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/GetAccountByIdRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetAccountByIdRequest xmlns=\"com.advantage.online.store.accountservice\"><accountId>655606527</accountId><base64Token>Basic ZGVtb3VzZXIyOkRlbW91c2VyMTIz</base64Token></GetAccountByIdRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_custom_request("GetAccountByIdNewRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/GetAccountByIdNewRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetAccountByIdNewRequest xmlns=\"com.advantage.online.store.accountservice\"><accountId>655606527</accountId><base64Token>Basic ZGVtb3VzZXIyOkRlbW91c2VyMTIz</base64Token></GetAccountByIdNewRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_url("655606527_4", 
		"URL=https://advantageonlineshopping.com/order/api/v1/carts/655606527", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("shippingcost", 
		"URL=https://advantageonlineshopping.com/order/api/v1/shippingcost/", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"seaddress\":{\"addressLine1\":\"abc\",\"addressLine2\":\"\",\"city\":\"hyderabad\",\"country\":\"in\",\"postalCode\":12345,\"state\":\"telangana\"},\"secustomerName\":\"user name\",\"secustomerPhone\":1234567890,\"senumberOfProducts\":2,\"setransactionType\":\"SHIPPING_COST\",\"sessionId\":\"EC1DFE9DC3CD2D4AA1720D327E761ADC\"}", 
		LAST);

	web_custom_request("GetAccountPaymentPreferencesRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/GetAccountPaymentPreferencesRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetAccountPaymentPreferencesRequest xmlns=\"com.advantage.online.store.accountservice\"><accountId>655606527</accountId><base64Token>Basic ZGVtb3VzZXIyOkRlbW91c2VyMTIz</base64Token></GetAccountPaymentPreferencesRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_url("orderPayment-page.html", 
		"URL=https://advantageonlineshopping.com/app/order/views/orderPayment-page.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/images/Bell.png", "Referer=https://advantageonlineshopping.com/css/main.min.css", ENDITEM, 
		LAST);

	web_custom_request("GetCountriesRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/GetCountriesRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><GetCountriesRequest xmlns=\"com.advantage.online.store.accountservice\"></GetCountriesRequest></soap:Body></soap:Envelope>", 
		LAST);

	lr_end_transaction("checkout_transaction",LR_AUTO);

	lr_think_time(84);

	lr_start_transaction("shipping_details_transaction");

	lr_end_transaction("shipping_details_transaction",LR_AUTO);

	lr_start_transaction("payment_method_transaction");

	lr_end_transaction("payment_method_transaction",LR_AUTO);

	lr_start_transaction("pay_now_transaction");

	web_custom_request("AddSafePayMethodRequest", 
		"URL=https://advantageonlineshopping.com/accountservice/ws/AddSafePayMethodRequest", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=UTF-8", 
		"Body=<?xml version=\"1.0\" encoding=\"UTF-8\"?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><AddSafePayMethodRequest xmlns=\"com.advantage.online.store.accountservice\"><safePayUsername>demouser</safePayUsername><accountId>655606527</accountId><safePayPassword>Demouser123</safePayPassword><base64Token>Basic ZGVtb3VzZXIyOkRlbW91c2VyMTIz</base64Token></"
		"AddSafePayMethodRequest></soap:Body></soap:Envelope>", 
		LAST);

	web_set_sockets_option("TLS_SNI", "1");

	web_custom_request("655606527_5", 
		"URL=https://advantageonlineshopping.com/order/api/v1/orders/users/655606527", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"orderPaymentInformation\":{\"Transaction_AccountNumber\":\"843200971\",\"Transaction_Currency\":\"USD\",\"Transaction_CustomerPhone\":1234567890,\"Transaction_MasterCredit_CVVNumber\":\"\",\"Transaction_MasterCredit_CardNumber\":\"4886\",\"Transaction_MasterCredit_CustomerName\":\"\",\"Transaction_MasterCredit_ExpirationDate\":\"122027\",\"Transaction_PaymentMethod\":\"SafePay\",\"Transaction_ReferenceNumber\":0,\"Transaction_SafePay_Password\":\"Demouser123\",\""
		"Transaction_SafePay_UserName\":\"demouser\",\"Transaction_TransactionDate\":\"4012024\",\"Transaction_Type\":\"PAYMENT\"},\"orderShippingInformation\":{\"Shipping_Address_Address\":\"abc\",\"Shipping_Address_City\":\"hyderabad\",\"Shipping_Address_CountryCode\":92,\"Shipping_Address_CustomerName\":\"user name\",\"Shipping_Address_CustomerPhone\":1234567890,\"Shipping_Address_PostalCode\":12345,\"Shipping_Address_State\":\"telangana\",\"Shipping_Cost\":19.98,\"Shipping_NumberOfProducts\":2,\""
		"Shipping_TrackingNumber\":0},\"purchasedProducts\":[{\"hexColor\":\"414141\",\"productId\":29,\"quantity\":2,\"hasWarranty\":false}]}", 
		LAST);

	web_custom_request("655606527_6", 
		"URL=https://advantageonlineshopping.com/order/api/v1/carts/655606527", 
		"Method=DELETE", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://advantageonlineshopping.com/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("pay_now_transaction",LR_AUTO);

	lr_start_transaction("close_transaction");

	lr_end_transaction("close_transaction",LR_AUTO);

	return 0;
}