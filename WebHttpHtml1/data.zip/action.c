Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=120", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://clients2.googleusercontent.com/crx/blobs/AeKPYwxH_khl3ineh7ieDifvVDmPCFIwpFpLPQ-D6PhdBT94OvOxzq7wflGWwcNRSp5o1S03Une4dRsNbaiinag-xOdQ71mVAzqVPjswIgjlWawgc3ktAMZSmuXHEQrP0bDGVk4fi_-eiVZzrdX--w/NDGIMIBANHLABGDGJCPBBNDIEHLJCPFH_5_1_8_0.crx", "Referer=", ENDITEM, 
		LAST);

	web_url("generate_204", 
		"URL=http://www.gstatic.com/generate_204", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}